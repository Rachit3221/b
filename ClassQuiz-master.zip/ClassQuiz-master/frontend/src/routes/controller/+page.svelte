<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->

<div>
	<h1 class="text-center text-8xl marck-script mt-12">ClassQuizController</h1>
	<div>
		<p class="text-center">Play a quiz with a physical controller, not on a touchscreen!</p>
	</div>
	<p class="text-center text-4xl m-12">More infos will follow soon</p>
</div>
