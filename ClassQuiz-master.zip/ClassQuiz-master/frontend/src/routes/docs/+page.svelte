<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->
<svelte:head>
	<title>ClassQuiz/docs - Index</title>
	<meta
		name="description"
		content="The overview about the docs for ClassQuiz, the open-source quiz-application"
	/>
</svelte:head>
<article
	class="prose prose-sm sm:prose lg:prose-lg xl:prose-xl mx-auto mt-10 prose-slate px-4 dark:prose-invert"
>
	<h1>Welcome to the ClassQuiz docs!</h1>
	<h2>Index</h2>
	<ul>
		<li>
			<a href="/docs/roadmap">Roadmap</a>
		</li>
		<li>
			<a href="/docs/import-from-kahoot">Import from Kahoot</a>
		</li>
		<li>
			<a href="/docs/self-host">Self-hosting</a>
		</li>
		<li>
			<a href="/docs/develop">Development-Setup</a>
		</li>
		<li>
			<a href="/docs/features">Features</a>
		</li>
	</ul>
</article>
