<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->

<!--<script lang='ts'>
	import { onMount } from 'svelte';
	import '$lib/hljs.css';

	onMount(async () => {
		const { default: hljs } = await import('highlight.js/lib/common');
		hljs.highlightAll();
	});
</script>-->

<svelte:head>
	<title>ClassQuiz/docs - Terms of Service</title>
	<meta
		name="description"
		content="The terms of service of ClassQuiz, the open-source quiz-application"
	/>
</svelte:head>

<article
	class="prose prose-sm sm:prose lg:prose-lg xl:prose-xl mx-auto mt-10 prose-slate px-4 dark:prose-invert"
>
	<h1>Terms of Service</h1>

	<h2>For those who don't like reading</h2>

	<ul>
		<li>
			<b>I</b> may do anything with the data you provide, stop providing this service, etc.
		</li>
		<li>
			<b
				>You don't upload, write, create any harmful content or anything that is against any
				German law.</b
			>
		</li>
	</ul>

	<h2>What doesn't belong on ClassQuiz</h2>
	<p>
		The owner may delete, change and modify any quiz. Quizzes with any pornography, illegal
		content or propaganda <b>have to be reported</b> and will be reviewed and deleted, if it's
		against these rules. This platform is made to share educational content, which can include
		anything, but <b>NO PORNOGRAPHY, ILLEGAL CONTENT or PROPAGANDA</b>.
		<i>I hope you understand what I mean.</i> 😇
	</p>
	<h2>How to report illegal content</h2>
	<p>You have to report illegal content by writing an email to report@mawoka.eu</p>
	<h2>The rights of the admin</h2>
	<p>
		The admin is allowed to publish <b>ANY</b> data provided by the user, although the admin
		doesn't want to do it. The admin can also delete <b>ANY</b> content, whether it's against any
		rule or not. ClassQuiz also doesn't provide any (uptime)-guarantee, so ClassQuiz could be shut
		down without any warning and without any ability for the user to get their data. The admin may
		publish any data provided by the user anywhere and share it with anyone.
	</p>
	<h2>The rights of the user</h2>
	<p>
		You can request the deletion of your data at any time by writing an email to
		deleteme@mawoka.eu. Please include the email you registered with on ClassQuiz, and, if
		possible, a prove that you are the owner of the account, by, eg., writing the email with the
		email-address which is associated with your ClassQuiz-account.
	</p>

	<h2>Final Words</h2>
	<p>
		All of that may sound hard, but, for example, the part with the data-publishing: What
		happens if data should be stolen and published? i don't run this platform to get insulted
		for publishing (personal) data, so I just make sure you're fine with that! Of course, I'll
		try to not publish any data, delete any content without a reason, etc, but I could. If you
		still got any questions, please contact me at <a href="https://mawoka.eu/contact"
			>mawoka.eu/contact</a
		>
	</p>
</article>
