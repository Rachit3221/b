<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->

<svelte:head>
	<title>ClassQuiz/docs - Roadmap</title>
	<meta
		name="description"
		content="The roadmap for ClassQuiz, the open-source quiz-application"
	/>
</svelte:head>
<article
	class="prose prose-sm sm:prose lg:prose-lg xl:prose-xl mx-auto mt-10 prose-slate px-4 dark:prose-invert"
>
	<h1>Roadmap</h1>

	<b>Tell me!</b>
	<ul>
		<li>
			<input type="checkbox" checked disabled />
			User-management
			<ul>
				<li><input type="checkbox" checked disabled /> Password-reset</li>
				<li><input type="checkbox" checked disabled /> Session-management</li>
			</ul>
		</li>
		<li><input type="checkbox" checked disabled /> (Better) Admin-screen styling</li>
		<li><input type="checkbox" checked disabled /> (Better) Edit/Create-screen styling</li>
		<li><input type="checkbox" checked disabled /> Public quiz-discovery</li>
	</ul>
</article>
