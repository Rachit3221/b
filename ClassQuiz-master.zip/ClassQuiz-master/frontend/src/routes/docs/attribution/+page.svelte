<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->

<svelte:head>
	<title>ClassQuiz/docs - Attribution</title>
	<meta name="description" content="People who helped making with ClassQuiz." />
</svelte:head>
<article
	class="prose prose-sm sm:prose lg:prose-lg xl:prose-xl mx-auto mt-10 prose-slate px-4 dark:prose-invert"
>
	<h1>People</h1>
	<h2>Contributors</h2>
	<p>People who contributed to the code on GitHub directly</p>
	<ul>
		<li>
			<a href="https://github.com/Dynnammo">Dynnammo</a>
		</li>
	</ul>
	<h2>Helpers</h2>
	<p>People who helped through issues (at least 2), tips, etc</p>
	<ul>
		<li>
			<a href="https://github.com/adeekshith">Deekshith</a>
		</li>
	</ul>
	<h2>Translators</h2>
	<p>
		People who translated ClassQuiz on <a href="https://translate.mawoka.eu/engage/classquiz/"
			>Weblate</a
		> or directly.
	</p>
	<ul>
		<li>
			<a href="https://github.com/liimee">liimee</a> (Indonesian)
		</li>
		<li>
			<a href="https://github.com/Dynnammo">Dynnammo</a> (French)
		</li>
		<li>
			<a href="https://github.com/ahmetlii">Ahmet</a> (Turkish)
		</li>
		<li>
			<a href="https://github.com/jmontane">Joan Montané</a> (Catalan)
		</li>
		<li>
			<a href="https://github.com/maxmasetti">Max</a> (Italian)
		</li>
		<li>
			<a href="https://github.com/RicoLaaa">RicoLaaa</a> (Spanish)
		</li>
		<li>
			<a href="https://github.com/WaldiSt">Waldemar Stoczkowski</a> (Polish)
		</li>
		<li>
			<a href="https://github.com/OptimisticSean">OptimisticSean</a> (Chinese)
		</li>
		<li>
			<a href="https://github.com/Miniontoby">Miniontoby</a> (Dutch)
		</li>
	</ul>

	<p><i>...Maybe you?</i></p>

	<h1>Rules</h1>
	<p>
		If you are listed once here, you're a part of ClassQuiz, forever! <br />
		You can also be listed in more categories.
	</p>
</article>
