<!--
SPDX-FileCopyrightText: 2023 Marlon W (Mawoka)

SPDX-License-Identifier: MPL-2.0
-->
Welcome to the ClassQuiz community

Grant and indulge critique constructively, within desired privacy.
Settle disputes within these confines.
Finding yourselves unable, e-mail hi@mawoka.eu answered by Marlon (Mawoka), the project maintainer.
